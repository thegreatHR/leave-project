<?php
include('checkmaintenance.php');
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- <meta name="viewport" content="width=device-width, initial-scale=1.0"> -->
    
    <title>GIET FORMS</title>
  <link rel="stylesheet" href="assets/style.css">
  <style>
    body {
  font-family: Arial, Helvetica, sans-serif;
  margin: 0;
}

html {
  box-sizing: border-box;
}

*, *:before, *:after {
  box-sizing: inherit;
}

.column {
  float: left;
  width: 33.3%;
  margin-bottom: 16px;
  padding: 0 8px;
}

.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  margin: 8px;
}

.about-section {
  padding: 30px;
  text-align: center;
  background-color: #474e5d;
  color: white;
}

.container {
  padding: 0 16px;
}

.container::after, .row::after {
  content: "";
  clear: both;
  display: table;
}

.title {
  color: grey;
}

.button {
  border: none;
  outline: 0;
  display: inline-block;
  padding: 8px;
  color: white;
  background-color: #000;
  text-align: center;
  cursor: pointer;
  width: 100%;
}

.button:hover {
  background-color: #555;
}


  </style>
  </head>
  <body>
    <?php
include('header.php');
?>
    <center><h1 class="pt-1 pb-1 text-red-600 ml-[350px] mr-[350px] rounded-xl bg-sky-500 text-4xl" >ABOUT US</h1></center><br>
  <h1 class="about-section" style="font-size: 250%;">OUR TEAM</h1>
  


<div class="row">
  <div class="column">
    <div class="card" style="background-color: white; padding-bottom: 8px;">
      <img src="/userimage/21CSE60/21CSE60.jpg"  alt="Jane" style="width:800px; height:633px">
      <div class="container">
        <h2>HARSH RAJ</h2>
        <p class="title">FULLSTACK DEVELOPER</p>
        <p>My name is HARSH RAJ, and I’m currently studying at GIET University. I have 1 year of experience in php language. I AM completeING MY Engg. in CSE Branch. My aim to digitize all the work in the world.<br><a href="https://www.linkedin.com/in/chintamani-pala" target="_blank" style="color:blue">FOLLOW ME ON LINKEDIN</a><br><a href="https://www.instagram.com/chintamani_pala/" target="_blank" style="color:blue">FOLLOW ME ON INSTAGRAM</a><br><a href="https://www.facebook.com/chintamanipala0" target="_blank" style="color:blue">FOLLOW ME ON FACEBOOK</a><br><a href="https://twitter.com/chintamani_pala" target="_blank" style="color:blue">FOLLOW ME ON TWITER</a></p>
        <p ><a href="mailto:HARSHRAJ8294213636@gmail.com" style="color:red">HARSHRAJ8294213636@gmail.com</a></p>
        
      </div>
    </div>
  </div>

  <div class="column">
    <div class="card" style="background-color: white; padding-bottom: 8px;">
      <img src="/userimage/21CSE59/21CS659.jpg" alt="Mike" style="width:800px; height:633px">
      <div class="container">
        <h2>T AVINASH</h2>
        <p class="title">WEB DESIGNER</p>
        <p>I am T AVINASH I am currently studying in GIETU and my diploma is complete Balaji institute of technology and science and interesting and web development</p>
        <p ><a href="mailto:gugulisagar@gmail.com" style="color:red">AMIT@gmail.com</a></p>
       
      </div>
    </div>
  </div>

  <div class="column">
    <div class="card" style="background-color: white; padding-bottom: 8px;">
      <img src="/userimage/21CSE665/21CSE665.jpg" alt="John" style="width:800px; height:633px">
      <div class="container">
        <h2>AMIT KUMAR</h2>
        <p class="title"></p>
        <p>My name is AMIT KUMAR. I am styding in GIET Universit.I completed my juniour Engg. from Centurion University in Mechanical Branch.</p>
        <p ><a href="mailto:khanr17389@gmail.com" style="color:red">khanr17389@gmail.com</a></p>
       
      </div>
    </div>
  </div>
</div>



      
            
                
              

</body>
</html>