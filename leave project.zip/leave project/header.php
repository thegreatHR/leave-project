<?php
include('checkmaintenance.php');
?>
<body class="font-serif bg-[url(https://urlsmoney.com/test/assets/sidebar.jpg)] bg-cover lg:bg-[url(https://source.unsplash.com/1600x900/?programming)]   ">
    <nav> <h1 align="center" class="text-white bg-sky-500 mt-2 ml-3 mr-3 mb-3  text-4xl rounded-xl"> GIET UNIVERSITY GUNUPUR ODISHA <br/> 765022</h1></nav>
   <div class="justify-center flex ">
        <ul><a href="index.php" class="ml-3 pt-1 pb-1 pl-3 pr-3 text-white bg-blue-600 rounded-lg text-clip text-xl hover:bg-blue-300">HOME</a></ul>
        <ul><a href="#" class="ml-3 pt-1 pb-1 pl-3 pr-3 text-white bg-blue-600 rounded-lg text-clip text-xl hover:bg-blue-300">ABOUT US</a></ul>
        <ul><a href="contact.php" class="ml-3 pt-1 pb-1 pl-3 pr-3 text-white bg-blue-600 rounded-lg text-clip text-xl hover:bg-blue-300">CONTACT US</a></ul>
        <ul><a href="credit.php" class="ml-3 pt-1 pb-1 pl-3 pr-3 text-white bg-blue-600 rounded-lg text-clip text-xl hover:bg-blue-300">CREDIT</a></ul>
        <ul><a href="./employee/" class="ml-3 pt-1 pb-1 pl-3 pr-3 text-white bg-blue-600 rounded-lg text-clip text-xl hover:bg-blue-300">EMPLOYEE LOGIN</a></ul>
        
        </div><br>