<?php
if(isset($_POST['refresh'])){
    header("Location: verify.php");
}
include('server.php');
session_start();
$rollno=$_SESSION['rollno'];




$sql = "select * from resister where ROLLNUMBER='$rollno';";
    $result=mysqli_query($conn,$sql);
    
    $row=mysqli_fetch_assoc($result);
    $otp=$row['otp'];
    
    $INOTP=(int)$otp;
    if(isset($_POST['submit'])){
            $OTP=$_POST['OTP'];
            
    
    
    
    }
    $intotp=(int)$OTP;

       
       
 
 
if($intotp==$INOTP){
            
            // $_SESSION['OTP']=$INOTP;
           
            $_SESSION['mailid']=$row['mailid'];
            $seotp=rand(1111,9999);
            $sessionotp=$seotp;
            $sql="UPDATE `resister` SET `sessionotp` = '$sessionotp' WHERE `resister`.`ROLLNUMBER` = '$rollno';";
            $result=mysqli_query($conn,$sql);
            $_SESSION['sessionotp']=$sessionotp;
       
        header("Location: welcome.php");
        
}

else{
    echo "INVALID OTP";
}
?>
<html>
<body>
    
    <span><div id="counter">5</div></span>
    <script>
        setInterval(function() {
            var div = document.querySelector("#counter");
            var count = div.textContent * 1 - 1;
            div.textContent = count;
            if (count == 1) {
                window.location.replace("./verify.php");
            }
        }, 1000);
    </script>
</body>
</html>