<?php
include('../server.php');
session_start();
if(!isset($_SESSION['empid'])){
    header("Location: index.php");
}
$employeeid=$_SESSION['empid'];
$sql="select * from employee where EMPLOYEEID ='$employeeid'";
    $result=mysqli_query($conn,$sql);
    if($result->num_rows>0)
    {
     
      $row=mysqli_fetch_assoc($result);
      $mailid=$row['EMAIL'];
      $_SESSION['EMAIL']=$mailid;
   
    }





$massage="YOUR LOGIN OTP IS<br>";
$subject="VERIFY YOUR OTP";
$CHECK=true;

$otp=rand(1111,9999);
$sql = "UPDATE employee SET otp = '$otp' WHERE 	EMPLOYEEID='$employeeid'";
if(mysqli_query($conn,$sql)){
    
    
}


	include('../mailconfig.php');
	$mail->Subject = $subject;
	$mail->Body =$massage." ".$otp;
	$mail->AddAddress($mailid);
	$mail->SMTPOptions=array('ssl'=>array(
		'verify_peer'=>false,
		'verify_peer_name'=>false,
		'allow_self_signed'=>false
	));
	if(!$mail->Send()){
		echo $mail->ErrorInfo;
	}else{
	
		
	}






?>
    



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- <meta name="viewport" content="width=device-width, initial-scale=1.0"> -->
    
    <title>GIET FORMS</title>
  <link rel="stylesheet" href="../assets/style.css">
</head>
<?php
include('empheader.php');
?>


 
        <center><h1 class="pt-1 pb-1 text-red-600 ml-[350px] mr-[350px] rounded-xl bg-sky-500 text-4xl" >VACATION FORM</h1></center><br>
<div class="flex center">
    <div class="flex-1 pt-3 text-center rounded-2xl mr-[300px] ml-[300px] bg-white pb-3">
            <center><h2 class="text-3xl"><b>EMPLOYEE LOGIN</b></h2></center><br>
        <form action="verify_otp.php" method="POST">
            
                
              <div><label for="fname" class="text-left text-xl">ENTER YOUR OTP</label><br>
                <input  class=" text-center text-xl" type="text" id="OTP" name="OTP" style="width: 300px" placeholder="ENTER OTP" ><br><br>
                         <span> <input type="submit" name="refresh" value="RESEND OTP" class=" text-xl rounded-lg bg-black text-white " style="width: 150px;height:50px"><span> <input type="submit" name="submit" value="SUBMIT OTP" class=" text-xl rounded-lg bg-black hover:bg-blue-800 text-white " style="width: 150px;height:50px">

              
           

</form>
       
      </div>    
</div>
</body>
</html>