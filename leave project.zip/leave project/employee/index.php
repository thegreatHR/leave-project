<?php
include('../checkmaintenance.php');
?>
<?php
session_start();
if(isset($_POST['validateLogin'])){
    $employeeid = $_POST['empid'];
    $_SESSION['empid']=$employeeid;
    
    header("Location: verify.php");
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- <meta name="viewport" content="width=device-width, initial-scale=1.0"> -->
    
    <title>GIET FORMS</title>
  <link rel="stylesheet" href="../assets/style.css">

</head>
<?php
include('empheader.php');
?>


<?php
  include('../server.php');
  $getresult=false;
  $otpiscorrect=false;
 
if(isset($_POST['submit'])){
  $empid=$_POST['empid'];

 
    $sql="select * from employee where EMPLOYEEID ='$empid'";
    $result=mysqli_query($conn,$sql);
    if($result->num_rows>0)
    {
     
      $row=mysqli_fetch_assoc($result);
      $fnames=$row['EMPLOYEENAME'];
      $employeeid=$empid;
      $DEPARTMENT=$row['DEPARTMENT'];
      $mailid=$row['EMAIL'];
      $getresult=true;
       
      
      
  }
  else
    {
     
      echo '<span class="text-red-600">
      <center class="text-red-600"><strong>EMPLOYEE ID IS WRONG</strong></center>
      
    </span>';
    }
    }
    
    

    

    


?>
        <center><h1 class="pt-1 pb-1 text-red-600 ml-[350px] mr-[350px] rounded-xl bg-sky-500 text-4xl" >VACATION FORM</h1></center><br>
<div class="flex center">
    <div class="flex-1 pt-3 text-center rounded-2xl mr-[300px] ml-[300px] bg-white pb-3">
        <center><h2 class="text-3xl"><b>EMPLOYEE SIGN IN</b></h2></center><br>
        <form action="index.php" method="POST">
            <?php
            if($getresult){
              echo '<label for="fname" class=" text-center text-xl">NAME&nbsp;&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</label>';
              echo  '<input type="text" id="fname" name="fname" value="';
              echo $fnames;
              echo '" name="fnames" style="width: 200px" readonly><br>';
              echo ' <label for="rollno"  class=" text-center text-xl">ROLL NUMBRER&nbsp;</label>&nbsp&nbsp&nbsp';
              echo '<input type="text" id="empid" name="empid" value="';
              echo $employeeid;
              echo '"name ="rollno" style="width: 200px" readonly><br>';
              echo ' <label for="rollno"  class=" text-center text-xl">DEPARTMENT&nbsp;</label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp';
              echo '<input type="text" id="rollno" name="branch" value="';
              echo $DEPARTMENT;
              echo '"name ="rollno" style="width: 200px" readonly><br>';
              echo '<center><label for="fname" class=" text-center text-xl">MAIL ID&nbsp;</label></center>';
              echo  '<center><input type="text" class="text-center" id="fname" value="';
              echo $mailid;
              echo '" name="fnames" style="width:350px" readonly></center><br><br>';
              

              
         

              echo<<< button
              
              <span> <center><input type="submit" name="validateLogin" value="VALIDATE" class=" text-xl rounded-lg bg-black hover:bg-blue-800 text-white " style="width: 150px;height:50px"></center></span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<br>
              <span><center><u><a class="text-red-600" href="./">i put wrong employee id!!</a></u></center></span>
              button;
            }else{

              echo <<< form

              <div><label for="fname" class=" text-left text-xl">EMPLOYEE ID</label><br>
                <input  class=" text-center text-xl" placeholder="ENTER YOUR EMPLOYEE ID" type="text" id="empid" name="empid" style="width: 300px" ><br><br>
                        <span> <input type="submit" name="submit" value="GET DETAILS" class=" text-xl rounded-lg bg-black hover:bg-blue-800 text-white " style="width: 150px;height:50px">

              form;

            }

            ?>
           

</form>
       
      </div>    
</div>
</body>
</html>