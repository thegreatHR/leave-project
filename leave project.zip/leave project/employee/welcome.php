<?php
$numava=false;
include('../server.php');
include('../checkmaintenance.php');
session_start();
$mailid=$_SESSION['EMAIL'];
$employeeid=$_SESSION['empid'];
if(!isset($_SESSION['EMAIL']) or !isset($_SESSION['empid'])){
    header("Location: index.php");
}
else{
    $sql = "select * from employee where EMPLOYEEID='$employeeid';";
    $result=mysqli_query($conn,$sql);
    
    $row=mysqli_fetch_assoc($result);
    
    
    
    
}
$sql="select * from leave_request where hodstatus='PENDING' ORDER BY id DESC";
$results=mysqli_query($conn,$sql);



// $rollno=$leaverow['ROLLNO'];

// $reason=$leaverow['reason'];

// $fromdate=$leaverow['fromdate'];

// $todate=$leaverow['todate'];



$num=mysqli_num_rows($results);
if($num>0){
    $numava=true;
}
?>
<?php
if(isset($_POST['submit'])){
$rollno=$_SESSION['rollno'];
$fromdate=$_SESSION['fromdate'];
$todate=$_SESSION['todate'];

$sqlit="select * from resister where ROLLNUMBER='$rollno'";
$qresults=mysqli_query($conn,$sqlit);
$rowse=mysqli_fetch_assoc($qresults);
$mailidstudent=$rowse['mailid'];


    $action=$_POST['action'];
    $comment=$_SESSION['reason'].'<br><br>COMMENT FROM HOD <br>'.$_POST['comment'].'<br><center><img alt="APPLICATION APPROVED" src="https://urlsmoney.com/test/assets/aapprove.jpg"></center>';
    $commentreject=$_SESSION['reason'].'<br><br>COMMENT FROM HOD <br>'.$_POST['comment'].'<br><center><img alt="APPLICATION REJECTED" src="https://urlsmoney.com/test/assets/areject.jpg"></center>';
if($action=="APPROVE"){

    $sql="UPDATE `leave_request` SET `hodstatus` = 'APPROVED' WHERE ROLLNO='$rollno' and fromdate='$fromdate' and todate='$todate'";
    $result=mysqli_query($conn,$sql);
    if($result){
    include('../mailconfig.php');
	$mail->Subject = "YOUR APPLICATION IS APPROVED SUCCESSFULLY";
	$mail->Body =  $comment;

	$mail->AddAddress($mailidstudent);
	$mail->SMTPOptions=array('ssl'=>array(
		'verify_peer'=>false,
		'verify_peer_name'=>false,
		'allow_self_signed'=>false
	));
	if(!$mail->Send()){
		echo $mail->ErrorInfo;
	}else{
	
		
	}
}
	header("Location: welcome.php");

}
elseif($action=="REJECT"){
    $sql="UPDATE `leave_request` SET `hodstatus` = 'REJECT' WHERE ROLLNO='$rollno' and fromdate='$fromdate' and todate='$todate'";
    $resultreject=mysqli_query($conn,$sql);
    if($result){
      include('../mailconfig.php');
	$mail->Subject = "YOUR APPLICATION IS REJECTED";
	$mail->Body =  $commentreject;

	$mail->AddAddress($mailidstudent);
	$mail->SMTPOptions=array('ssl'=>array(
		'verify_peer'=>false,
		'verify_peer_name'=>false,
		'allow_self_signed'=>false
	));
	if(!$mail->Send()){
		echo $mail->ErrorInfo;
	}else{
	
		
	}
}
	header("Location: welcome.php");

    
}
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- <meta name="viewport" content="width=device-width, initial-scale=1.0"> -->
    
    <title>GIET FORMS</title>
  
  <link rel="stylesheet" href="../assets/style.css">
  <SCRIPT LANGUAGE="JavaScript">
function onlyOne(checkbox) {
    var checkboxes = document.getElementsByName('check')
    checkboxes.forEach((item) => {
        if (item !== checkbox) item.checked = false
    })
}
var message="Sorry, right-click has been disabled";
///////////////////////////////////
function clickIE() {if (document.all) {(message);return false;}}
function clickNS(e) {if
(document.layers||(document.getElementById&&!document.all)) {
if (e.which==2||e.which==3) {(message);return false;}}}
if (document.layers)
{document.captureEvents(Event.MOUSEDOWN);document.onmousedown=clickNS;}
else{document.onmouseup=clickNS;document.oncontextmenu=clickIE;}
document.oncontextmenu=new Function("return false")
// -->
</SCRIPT>

<style>

        table {

            margin: 0 auto;

            font-size: large;

            border: 1px solid black;
           
            background-color: red;
            

        }
 

        h1 {

            text-align: center;

            color: #006600;

            font-size: xx-large;

            font-family: 'Gill Sans', 'Gill Sans MT',

            ' Calibri', 'Trebuchet MS', 'sans-serif';

        }
 

        td {

            background-color: #E4F5D4;

            border: 1px solid black;

        }
 

        th,

        td {

            font-weight: bold;

            border: 1px solid black;

            padding: 10px;

            text-align: center;

        }
 

        td {

            font-weight: lighter;

        }
         th {

            background-color: blue;

            border: 1px solid black;

        }

    </style>


</head>
<body>
<?php
include('../headerloged.php');
// include('sessionvalidate.php');
?>



  
        <center><h1 class="pt-1 pb-1 text-red-600 ml-[350px] mr-[350px] rounded-xl bg-sky-500 text-3xl" >WELCOME EMPLOYEE <?php echo $row['EMPLOYEENAME'] ?> </h1></center><br>
<div class="flex">

    <div class=" flex-1 pt-3 rounded-2xl mr-[120px] ml-[120px]  pb-3" style="
    background-color: darkblue;
    padding: 25px;
    ">
         <form action="welcome.php" method="POST">
            <section>
            

        <!-- TABLE CONSTRUCTION -->
<?php
if($numava){
        echo '<table>';

           echo '<tr>';

               echo '<th>ROLL NO</th>';

                echo '<th>REASON</th>';

                echo '<th>FROM DATE</th>';

                echo '<th>TO DATE</th>';
                echo '<th>ACTION</th>';

            echo '</tr>';
}
?>

            <!-- PHP CODE TO FETCH DATA FROM ROWS -->

            <?php 
            if($numava){
            
            
           $count=0;
            while($rows=mysqli_fetch_assoc($results)){
               if($count==1){
                   break;
               }
                
            
   

            
                // LOOP TILL END OF DATA

                

            ?>

            <tr>

                <!-- FETCHING DATA FROM EACH

                    ROW OF EVERY COLUMN -->

                <td  style="width:10%">
                <?php
                echo $rows['ROLLNO']; 
                $_SESSION['rollno']=$rows['ROLLNO'];
                
                ?>
                </td>

                 <td  style="width:50%">
                <?php 
                echo $rows['reason']; 
                $_SESSION['reason']=$rows['reason'];
                ?>
                </td>

                <td  style="width:10%">
                <?php 
                echo $rows['fromdate'];
                $_SESSION['fromdate']=$rows['fromdate'];
                
                ?></td>

                <td  style="width:10%">
                <?php 
                echo $rows['todate'];
                $_SESSION['todate']=$rows['todate'];
                
                ?></td>

<td  style="width:20%">
                
<span><select name="action" id="action">
<option name="approve" value="APPROVE">APPROVE</option>
<option name="reject" value="REJECT">REJECT</option>
  
</select></span><br></td>



            </tr>

            <?php
            $count++;
            }
            }
            
            else{
                echo '<center><h1 class="pt-1 pb-1 text-red-600 rounded-xl text-4xl" >NO APPLICATION PENDING</h1></center><br>';
            
                }

            ?>

        </table>
    </section>
    <br>
    <br>
    <?php
if($numava){
    echo '<center><label for="comment" style="';
    echo 'color: ivory;">COMMENT OF APPLICATION</label></span><br><div style="height: 120px"><textarea maxlength="430" type="text" style=" resize: none; height: 120px;width: 600px;text-align: left;border-radius: 14px;" id="comment" name="comment"required></textarea></div><br><span> <input type="submit" name="submit" value="SUBMIT" class="text-xl rounded-lg bg-black hover:bg-blue-800 text-white " style="width: 150px;height:50px"></center>';
}
?>
    </form>
       
      </div>    
</div>
</body>
</html>

