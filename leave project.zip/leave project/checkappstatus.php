<?php
include('checkmaintenance.php');
?>

<?php
$numava=false;
session_start();
include('server.php');
if(!isset($_SESSION['rollno'])){
     header("Location: index.php");
}
$rollno=$_SESSION['rollno'];

$sql="select * from leave_request where ROLLNO='$rollno' ORDER BY id DESC";
$results=mysqli_query($conn,$sql);

$num=mysqli_num_rows($results);

if($num>0){
    $numava=true;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- <meta name="viewport" content="width=device-width, initial-scale=1.0"> -->
    
    <title>GIET FORMS</title>
  <link rel="stylesheet" href="assets/style.css">
  <style>

        table {

            margin: 0 auto;

            font-size: large;

            border: 1px solid black;

        }
 

        h1 {

            text-align: center;

            color: #006600;

            font-size: xx-large;

            font-family: 'Gill Sans', 'Gill Sans MT',

            ' Calibri', 'Trebuchet MS', 'sans-serif';

        }
 

        td {

            background-color: #E4F5D4;

            border: 1px solid black;

        }
 

        th,

        td {

            font-weight: bold;

            border: 1px solid black;

            padding: 10px;

            text-align: center;

        }
 

        td {

            font-weight: lighter;

        }

    </style>

</head>
<?php
include('headerlogedleave.php');

?>

    <div class="flex-1 pt-3 text-center rounded-2xl mr-[120px] ml-[120px] bg-white pb-3">
        <center><h2 class="text-3xl"><b>APPLICATION STATUS</b></h2></center><br>
        <form action="index.php" method="POST">
            <section>
            

        <!-- TABLE CONSTRUCTION -->
<?php

if($numava){
        echo '<table>';

           echo '<tr>';

               echo '<th>POST TIME</th>';

                echo '<th>REASON</th>';

                echo '<th>FROM DATE</th>';

                echo '<th>TO DATE</th>';
                echo '<th>STATUS</th>';

            echo '</tr>';
}
?>

            <!-- PHP CODE TO FETCH DATA FROM ROWS -->

            <?php 
            if($numava){

            while($row=mysqli_fetch_assoc($results)){
            
            ?>

            <tr>

                <!-- FETCHING DATA FROM EACH

                    ROW OF EVERY COLUMN -->

                <td style="width:10%"><?php echo $row['Posttime'];?></td>

                <td style="width:50%"><?php echo $row['reason'];?></td>

                <td style="width:10%"><?php echo $row['fromdate'];?></td>

                <td style="width:10%"><?php echo $row['todate'];?></td>
                <td style="width:10%"><?php echo $row['hodstatus'];?></td>

            </tr>

            <?php
            }
            }
            
            else{
                echo '<center><h1 class="pt-1 pb-1 text-red-600 rounded-xl text-4xl" >NO APPLICATION PENDING</h1></center><br>';
            
                }

            ?>

        </table>

    </section>
           

</form>
       
      </div>    
</div>
</body>
</html>