

<?php
include('smtp/PHPMailerAutoload.php');
$mail = new PHPMailer(); 
//$mail->SMTPDebug=3;
	$mail->IsSMTP(); 
	$mail->SMTPAuth = true; 
	$mail->SMTPSecure = 'tls'; 
	$mail->Host = "smtp.gmail.com";
	$mail->Port = "587"; 
	$mail->IsHTML(true);
	$mail->CharSet = 'UTF-8';
	$mail->Username = "21cse070.harshraj@giet.edu";
	$mail->Password = '7367039121';
	$mail->SetFrom("21cse070.harshraj@giet.edu");
?>