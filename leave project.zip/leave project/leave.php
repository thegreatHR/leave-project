<?php
include('checkmaintenance.php');
?>
<?php
include('server.php');
session_start();
$mailid=$_SESSION['mailid'];
$rollno=$_SESSION['rollno'];
if(!isset($_SESSION['mailid'])){
    header("Location: index.php");
}
else{
   $sql = "select * from resister where ROLLNUMBER='$rollno'";
    $result=mysqli_query($conn,$sql);
    
    $row=mysqli_fetch_assoc($result);
    
    $fnames=$row['SFULLNAME'];
    $rollnumber=$row['ROLLNUMBER'];
    $branch=$row['BRANCH'];
    $section=$row['SECTION'];
    $mailid=$row['mailid'];
    $proctoremployeeid=$row['proctoremployeeid'];
    $ctemployeeid=$row['ctemployeeid'];
    $yearhodemployeeid=$row['yearhodemployeeid'];
}

?>

<?php
$resultisvalid="0";
if(isset($_POST['submit'])){
    
    $fromdate=$_POST['dfrom'];
    $timestamp = strtotime($fromdate);
    $fromdates = date("Y-m-d", $timestamp);
    $fromdated=date("d-m-Y",$timestamp);
   
    $todate=$_POST['tfrom'];
    $timestamp = strtotime($todate);
    $todates = date("Y-m-d", $timestamp);
    $todated=date("d-m-Y",$timestamp);
    function dateDifference($start_date, $end_date)
    {
    // calulating the difference in timestamps 
    $diff = strtotime($start_date) - strtotime($end_date);
      
    // 1 day = 24 hours 
    // 24 * 60 * 60 = 86400 seconds
    return ceil(abs($diff / 86400));
    }
  
// start date 
    $start_date =$fromdates ;
  
// end date 
    $end_date = $todates ;
  
// call dateDifference() function to find the number of days between two dates
    $dateDiff = dateDifference($start_date, $end_date);
  
    $dateinterval=(int)$dateDiff;
     
   
    if($dateinterval>10){
        $invaliddate="1";
        
    }
    else
    {
        
    $appli=$_POST['lreason'];
    $rollno=$_POST['rollno'];
    $mailid=$_SESSION['mailid'];
   
    $sql = "INSERT INTO leave_request(ROLLNO,reason,fromdate,todate, proctoremployeeid,ctemployeeid,yearhodemployeeid,Posttime) VALUES ('$rollno','$appli','$fromdated','$todated','$proctoremployeeid','$ctemployeeid','$yearhodemployeeid','$todaytime')";
    $result=mysqli_query($conn,$sql);
    print_r(mysqli_error($conn));
    
    $resultisvalid="0";
    if($result){
        $resultisvalid="1";
       
        
        include('mailconfig.php');
	$mail->Subject = "YOUR APPLICATION IS SUBMITTED SUCCESSFULLY";
	$mail->Body = "$appli".'<br>YOUR APPLICATION IS UNDER PROCESSING<br>YOUR APPLICATION IS VALID FROM '.$fromdated." TO ".$todated.'<br><center><img alt="PHPMailer" src="https://cms.jotform.com/uploads/answers/answer/btzap/595457_111.jpg"></center>';

	$mail->AddAddress($mailid);
	$mail->SMTPOptions=array('ssl'=>array(
		'verify_peer'=>false,
		'verify_peer_name'=>false,
		'allow_self_signed'=>false
	));
	if(!$mail->Send()){
		echo $mail->ErrorInfo;
	}else{
	
		
	}
		
	}
    
    }
    
    
}

    

?>
<?php
 date_default_timezone_set("Asia/Calcutta");
?>
<html>
<title>GIET UNIVERSITY VACATION</title>
    <head> 
        
    <link rel="stylesheet" type="text/css" href="assets/style.css"/>
    <!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous"> -->

    </head>
   <body>
   
   <?php 
   include('headerlogedleave.php'); 
   //include('sessionvalidate.php');
   ?>
   <?php
   
   if(isset($_POST['submit'])){
   
   if($resultisvalid=="1"){
       
       echo '<center><h3 class="pt-1 pb-1 text-white ml-[350px] mr-[350px] rounded-xl bg-blue-600" >';
        echo 'APPLICATION SUBMITTED SUCCESSFULLY';
        echo '</h3></center><div class="flex-container"> <br>';
   }
   elseif($invaliddate=="1"){
           echo '<center><h3 class="pt-1 pb-1 text-white ml-[350px] mr-[350px] rounded-xl bg-red-500" >';
        echo 'PLEASE CHOOSE A VALID DATE';
        echo '</h3></center><div class="flex-container"> <br>';
   }
   else{
       echo '<center><h3 class="pt-1 pb-1 text-white ml-[350px] mr-[350px] rounded-xl bg-red-500" >';
        echo 'APPLICATION IS NOT SUBMITTED CONTACT ADMIN';
        echo '</h3></center><div class="flex-container"> <br>';
   }
   
   }
   ?>

<?php
     $sqlio="select * from resister where ROLLNUMBER ='$rollno';";
  $resultr=mysqli_query($conn,$sqlio);
  $rowsr=mysqli_fetch_assoc($resultr);
echo '<center><h1 class="pt-1 pb-1 text-red-600 ml-[350px] mr-[350px] rounded-xl bg-sky-500 text-3xl" >';
    echo 'WELCOME '.$rowsr['SFULLNAME'];
    echo '</h1></center><div class="flex-container"> <br>';
    ?>


<div class="flex center">
    <div class="h-160 ml-[120px] mr-[120px] flex-1 pt-3 text-center rounded-2xl center bg-blue-600 pb-3 "><br>
    <form action="leave.php" method="POST">
        <label for="fname" class="lform">NAME&nbsp;</label>
        <?php
            echo  '<input class="rounded-lg" type="text" id="fname" value="';
            echo $fnames;
            echo '" name="fnames" style="width: 200px" disabled>';
        ?>
                &nbsp<label for="rollno"  class="lform">ROLL NUMBRER&nbsp;</label>
        <?php
            echo '<input class="rounded-lg" type="text" id="rollno" value="';
            echo $rollnumber;
            echo '"name ="rollno" style="width: 200px" readonly><br><br>';
            ?>
           <span><label for="fname" class="lform">MAIL ID&nbsp;</label>
        <?php
            echo  '<input class="rounded-lg" type="text" id="fname" value="';
            echo $mailid;
            echo '" name="fnames" style="width: 380px" READONLY></span>';
        ?>
        <br><br>
        <span><label for="branch" class="lform">BRANCH&nbsp;</label>
        <?php
            echo  '<input class="rounded-lg" type="text" id="fname" value="';
            echo $branch;
            echo '" name="fnames" style="width: 200px" disabled></span>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp';
        ?>
                <label for="section"  class="lform">SECTION&nbsp;</label>
        <?php
            echo '<input class="rounded-lg" type="text" id="rollno" value="';
            echo $section;
            echo '"name ="rollno" style="width: 200px" disabled><br><br>';
        ?>
        <span><label for="fname" class="rounded-lg">FROM&nbsp;</label>
                <input type="date" class="rounded-lg" min="<?php echo date("Y-m-d"); ?>" id="dfrom" name="dfrom" style="width: 200px" required></span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp&nbsp;
                <span><label for="dfrom" class="rounded-lg">TO&nbsp;</label>
                <input type="date" min="<?php echo date("Y-m-d"); ?>" id="tfrom" name="tfrom" class="rounded-lg" style="width: 200px" required></span><br><br>
        <div class="reason"><label for="dfrom" class="rounded-lg">DESCRIBE YOUR REASON&nbsp;</label><br><br>
                <textarea class="rounded-lg" type="text" id="lreason" name="lreason" style="resize: none;width: 600px;height: 120px" required></textarea><br></div><br><br>
                <span> <input type="submit" name="submit" value="SUBMIT" class="text-xl rounded-lg bg-black hover:bg-blue-800 text-white " style="width: 150px;height:50px">
    </form>
    </div>
</div>
  
</body>
</html>