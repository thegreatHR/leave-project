<?php
include('checkmaintenance.php');
?>
<?php
include('server.php');

session_start();
$mailid = $_SESSION['mailid'];
$rollno = $_SESSION['rollno'];

if (!isset($_SESSION['rollno']) or !isset($_SESSION['mailid'])) {
  header("Location: index.php");
} else {
  $sql = "select * from resister where mailid='$mailid';";
  $result = mysqli_query($conn, $sql);

  $row = mysqli_fetch_assoc($result);
  $imagepath = $row['imagepath'];
  $sqlio = "select * from resister where ROLLNUMBER ='$rollno';";
  $resultr = mysqli_query($conn, $sqlio);
  $rowsr = mysqli_fetch_assoc($resultr);
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <!-- <meta name="viewport" content="width=device-width, initial-scale=1.0"> -->

  <title>GIET FORMS</title>

  <link rel="stylesheet" href="assets/style.css">
  <SCRIPT LANGUAGE="JavaScript">
    var message = "Sorry, right-click has been disabled";
    ///////////////////////////////////
    function clickIE() {
      if (document.all) {
        (message);
        return false;
      }
    }

    function clickNS(e) {
      if (document.layers || (document.getElementById && !document.all)) {
        if (e.which == 2 || e.which == 3) {
          (message);
          return false;
        }
      }
    }
    if (document.layers) {
      document.captureEvents(Event.MOUSEDOWN);
      document.onmousedown = clickNS;
    } else {
      document.onmouseup = clickNS;
      document.oncontextmenu = clickIE;
    }
    document.oncontextmenu = new Function("return false")
    // -->
  </SCRIPT>




</head>

<body>
  <?php
  include('headerloged.php');
  //include('sessionvalidate.php');
  ?>




  <center>
    <h1 class="pt-1 pb-1 text-red-600 ml-[350px] mr-[350px] rounded-xl bg-sky-500 text-3xl">WELCOME <?php echo $rowsr['SFULLNAME'] ?> </h1>
  </center><br>
  <div class="flex center">
    &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<?php echo '<img class="mt20 rounded-xl" src="userimage/';
                                                                echo $rollno;
                                                                echo "/";
                                                                echo $rollno;
                                                                echo '.jpg"style="float:left;width:180px;height:250px;margin-top: 50px;">';
                                                                ?>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
    <div class="h-70 flex-1 pt-3 text-center rounded-2xl mr-[300px]  bg-blue-600 pb-3">
      <center>
        <h2 class="text-3xl"><b>SUBMIT YOUR APPLICATION</b></h2>
      </center><br>





      <span> <a href="leave.php"><input type="submit" name="submit" value="SUBMIT LEAVE APPLICATION" class=" text-xl rounded-lg bg-black hover:bg-blue-800 text-white " style="width: 350px;height:50px"></a><br>
        <br><br><br><br><br>
        <span> <input type="submit" name="submit" value="UPLOAD  MANUAL APPLICATION" class=" text-xl rounded-lg bg-black hover:bg-blue-800 text-white " style="width: 350px;height:50px"><br>

          </form>

    </div>
  </div>
</body>

</html>