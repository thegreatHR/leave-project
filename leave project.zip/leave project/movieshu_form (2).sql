-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 08, 2023 at 01:26 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `movieshu_form`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `adminid` varchar(110) NOT NULL,
  `adminpass` varchar(1100) NOT NULL,
  `adminname` varchar(110) NOT NULL,
  `adminemail` varchar(100) NOT NULL,
  `adminaddress` varchar(1100) NOT NULL,
  `adminjoindate` varchar(110) NOT NULL,
  `otp` int(11) NOT NULL,
  `sessionotp` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`adminid`, `adminpass`, `adminname`, `adminemail`, `adminaddress`, `adminjoindate`, `otp`, `sessionotp`) VALUES
('21cs660', 'kuna@1234', 'chintamani pala', 'chintamanipala67@gmail.com', 'no', 'no', 3150, 9009);

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `EMPLOYEEID` varchar(100) NOT NULL,
  `EMPLOYEENAME` varchar(100) NOT NULL,
  `EMAIL` varchar(100) NOT NULL,
  `DEPARTMENT` varchar(100) NOT NULL,
  `JOINDATE` varchar(100) NOT NULL,
  `MOBILENO` varchar(100) NOT NULL,
  `otp` varchar(10) NOT NULL,
  `sessionotp` varchar(100) NOT NULL,
  `imagepath` varchar(200) NOT NULL DEFAULT '../employeeimage/'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`EMPLOYEEID`, `EMPLOYEENAME`, `EMAIL`, `DEPARTMENT`, `JOINDATE`, `MOBILENO`, `otp`, `sessionotp`, `imagepath`) VALUES
('760590044', 'SUBHAM KUMAR SINHA', 'idk@gmail.com', '', '', '1', '', '', ''),
('7605900445', 'KUNA', 'chintamanipala67@gmail.com', 'CSE', '', '2', '5299', '5526', 'employeeimage/7605900445/7605900445.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `function`
--

CREATE TABLE `function` (
  `id` int(11) NOT NULL,
  `maintenance` int(10) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `function`
--

INSERT INTO `function` (`id`, `maintenance`) VALUES
(1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `leave_request`
--

CREATE TABLE `leave_request` (
  `id` int(11) NOT NULL,
  `ROLLNO` varchar(100) NOT NULL,
  `reason` text NOT NULL,
  `fromdate` varchar(100) NOT NULL,
  `todate` varchar(100) NOT NULL,
  `proctorstatus` varchar(400) NOT NULL DEFAULT 'PENDING',
  `classteacherstatus` varchar(100) NOT NULL DEFAULT 'PENDING',
  `hodstatus` varchar(100) NOT NULL DEFAULT 'PENDING',
  `Posttime` datetime NOT NULL DEFAULT current_timestamp(),
  `FSTATUS` varchar(100) NOT NULL DEFAULT 'PENDING',
  `PROCTORCONTACTWITHPARENT` text DEFAULT NULL,
  `PROCTORCONACTPARENTMOBILENO` varchar(100) DEFAULT NULL,
  `HODVERIFICATION` text DEFAULT NULL,
  `proctoremployeeid` varchar(100) NOT NULL,
  `ctemployeeid` varchar(100) NOT NULL,
  `yearhodemployeeid` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `leave_request`
--

INSERT INTO `leave_request` (`id`, `ROLLNO`, `reason`, `fromdate`, `todate`, `proctorstatus`, `classteacherstatus`, `hodstatus`, `Posttime`, `FSTATUS`, `PROCTORCONTACTWITHPARENT`, `PROCTORCONACTPARENTMOBILENO`, `HODVERIFICATION`, `proctoremployeeid`, `ctemployeeid`, `yearhodemployeeid`) VALUES
(216, '21CSE660', 'hii', '05-12-2022', '06-12-2022', 'PENDING', 'PENDING', 'APPROVED', '2022-12-05 10:33:00', 'PENDING', NULL, NULL, NULL, '7605900445', '70590044', '123456789'),
(217, '21CSE660', 'my health is not good', '05-12-2022', '06-12-2022', 'PENDING', 'PENDING', 'APPROVED', '2022-12-05 10:39:27', 'PENDING', NULL, NULL, NULL, '7605900445', '70590044', '123456789'),
(218, '21CSE660', 'NLKLKK', '05-12-2022', '13-12-2022', 'PENDING', 'PENDING', 'pending', '2022-12-05 21:54:30', 'PENDING', NULL, NULL, NULL, '7605900445', '70590044', '123456789'),
(219, '21CSE659', 'H\r\n\r\n\r\n\r\nTYUUTU\r\n7ITYU\r\n\r\n\r\n87O8967\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\nOYIY\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\nULIY', '06-12-2022', '12-12-2022', 'PENDING', 'PENDING', 'pending', '2022-12-06 09:37:28', 'PENDING', NULL, NULL, NULL, '', '', ''),
(220, '21CSE660', 'my health is not good', '06-12-2022', '09-12-2022', 'PENDING', 'PENDING', 'APPROVED', '2022-12-06 10:26:09', 'PENDING', NULL, NULL, NULL, '', '', ''),
(221, '21cse236', ' nvmnvxm,v', '18-02-2023', '20-02-2023', 'PENDING', 'PENDING', 'PENDING', '2023-02-04 17:43:32', 'PENDING', NULL, NULL, NULL, '123', '123', '');

-- --------------------------------------------------------

--
-- Table structure for table `resister`
--

CREATE TABLE `resister` (
  `SFULLNAME` varchar(100) NOT NULL,
  `BRANCH` varchar(100) NOT NULL,
  `SECTION` varchar(10) NOT NULL,
  `ROLLNUMBER` varchar(100) NOT NULL,
  `HOSTELNO` varchar(100) NOT NULL DEFAULT 'NO',
  `WARDENNAME` varchar(100) NOT NULL,
  `proctorname` varchar(100) NOT NULL,
  `proctoremployeeid` varchar(100) NOT NULL,
  `CLASSTEACHER` varchar(100) NOT NULL,
  `ctemployeeid` varchar(100) NOT NULL,
  `YEARHOD` varchar(100) NOT NULL,
  `yearhodemployeeid` varchar(100) NOT NULL,
  `HOD` varchar(100) NOT NULL,
  `mailid` varchar(100) NOT NULL,
  `otp` varchar(10) NOT NULL,
  `imagepath` varchar(200) NOT NULL DEFAULT 'userimage/',
  `sessionotp` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `resister`
--

INSERT INTO `resister` (`SFULLNAME`, `BRANCH`, `SECTION`, `ROLLNUMBER`, `HOSTELNO`, `WARDENNAME`, `proctorname`, `proctoremployeeid`, `CLASSTEACHER`, `ctemployeeid`, `YEARHOD`, `yearhodemployeeid`, `HOD`, `mailid`, `otp`, `imagepath`, `sessionotp`) VALUES
('$sname', ' $sbranch', '$ssec', '$srollno', '$shostelno', '', '', '$proctorid', '', '$classtecherid', '', '', '', '$emailid', '', 'userimage/', NULL),
('ASHISH KUMAR BEHERA', ' CSE', 'C', '21CSE101', 'NC 12', '', '', '123', '', '456', '', '', '', '21CSE101.ASHISHKUMARBEHERA@GIET.EDU', '', 'userimage/', NULL),
('ASHISH KUMAR BEHERA', ' CSE', 'C', '21CSE102', 'NC 12', '', '', '123', '', '456', '', '', '', '21CSE11.ASHISHKUMARBEHERA@GIET.EDU', '', 'userimage/', NULL),
('gopal krushna shaw', ' CSE', 'C', '21cse236', 'NC 10 ROOM 52', '', '', '123', '', '123', '', '', '', 'gopalkrushnashaw7@gmail.com', '3500', 'userimage/', '8294'),
('Chintamani Pala', 'CSE', 'C', '21CSE660', 'NC 4 ROOM 10', '', '', '', '', '', '', '', '', 'CHINTAMANIPALA67@GMAIL.COM', '5455', 'userimage/', '8791');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`adminid`),
  ADD UNIQUE KEY `adminemail` (`adminemail`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`EMPLOYEEID`),
  ADD UNIQUE KEY `EMAIL` (`EMAIL`),
  ADD UNIQUE KEY `MOBILENO` (`MOBILENO`);

--
-- Indexes for table `function`
--
ALTER TABLE `function`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `leave_request`
--
ALTER TABLE `leave_request`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `resister`
--
ALTER TABLE `resister`
  ADD PRIMARY KEY (`ROLLNUMBER`),
  ADD UNIQUE KEY `mailid` (`mailid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `function`
--
ALTER TABLE `function`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `leave_request`
--
ALTER TABLE `leave_request`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=222;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
