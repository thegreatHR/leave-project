
<?php
$servername='localhost';
 $username='root';
 $password='';
 $database='leave';
 $conn=mysqli_connect($servername,$username,$password,$database);
 if(!$conn)
 {
     
     echo '<span class="alert-denger">
     <center class="alert-denger"><strong>WEBSITE IS UNDER MAINTAINANCE</strong></center>
     
   </span>';
 }
 date_default_timezone_set("Asia/Kolkata");
 $todaytime=date('Y-m-d H:i:s');
 ?>