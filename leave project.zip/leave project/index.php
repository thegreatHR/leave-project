<?php
include('checkmaintenance.php');
session_start();
if(isset($_POST['validateLogin'])){
    $rollno = strtoupper($_POST['rollno']);
    $_SESSION['rollno']=$rollno;
    
    header("Location: verify.php");
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- <meta name="viewport" content="width=device-width, initial-scale=1.0"> -->
    
    <title>GIET FORMS</title>
  <link rel="stylesheet" href="assets/style.css">

</head>
<?php
include('header.php');
?>


<?php
  include('server.php');
  $getresult=false;
  $otpiscorrect=false;
 
if(isset($_POST['submit'])){
  $rollno=strtoupper($_POST['rollno']);

 
    $sql="select * from resister where ROLLNUMBER ='$rollno'";
    $result=mysqli_query($conn,$sql);
    if($result->num_rows>0)
    {
     
      $row=mysqli_fetch_assoc($result);
      $fnames=$row['SFULLNAME'];
      $rollnumber=$rollno;
      $ba=substr($rollno,0,2);
      $bat=(int)$ba;
      $batch=$bat+4;
      $branch=$row['BRANCH'];
      $section=$row['SECTION'];
      $hostel=$row['HOSTELNO'];
      $mailid=$row['mailid'];
      $getresult=true;
       
      
      
  }
  else
    {
     
      echo '<span class="text-red-600">
      <center class="text-red-600"><strong>ROLL NUMBER IS WRONG</strong></center>
      
    </span>';
    }
    }
    
    

    

    


?>
        <center><h1 class="pt-1 pb-1 text-red-600 ml-[350px] mr-[350px] rounded-xl bg-sky-500 text-4xl" >VACATION FORM</h1></center><br>
<div class="flex center">
    <div class="flex-1 pt-3 text-center rounded-2xl mr-[300px] ml-[300px] bg-white pb-3">
        <center><h2 class="text-3xl"><b>SIGN IN</b></h2></center><br>
        <form action="index.php" method="POST">
            <?php
            if($getresult){
              echo '<label for="fname" class=" text-center text-xl">NAME&nbsp;&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</label>';
              echo  '<input type="text" id="fname" name="fname" value="';
              echo $fnames;
              echo '" name="fnames" style="width: 200px" readonly><br>';
              echo ' <label for="rollno"  class=" text-center text-xl">ROLL NUMBRER&nbsp;</label>&nbsp&nbsp&nbsp';
              echo '<input type="text" id="rollno" name="rollno" value="';
              echo $rollnumber;
              echo '"name ="rollno" style="width: 200px" readonly><br>';
              echo ' <label for="rollno"  class=" text-center text-xl">BRANCH&nbsp;</label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp';
              echo '<input type="text" id="rollno" name="branch" value="';
              echo $branch;
              echo '"name ="rollno" style="width: 200px" readonly><br>';
              echo ' <label for="rollno"  class=" text-center text-xl">SECTION&nbsp;</label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp';
              echo '<input type="text" id="rollno" name="section" value="';
              echo $section;
              echo '"name ="rollno" style="width: 200px" readonly><br>';
             
              echo '<label for="fname" class=" text-center text-xl">BATCH&nbsp;</label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp';
              echo  '<input type="text" id="fname" value="';
              echo "20".$bat." - "."20".$batch;
              echo '" name="fnames" style="width: 200px" readonly>';
              
              echo '<br><span><label for="fname" class=" text-center text-xl">HOSTEL&nbsp;</label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp';
              echo  '<input type="text" id="fname" value="';
              echo $hostel;
              echo '" name="fnames" style="width: 150px" readonly></span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<br><br>';
              echo '<center><label for="fname" class=" text-center text-xl">MAIL ID&nbsp;</label></center>';
              echo  '<center><input type="text" class="text-center" id="fname" value="';
              echo $mailid;
              echo '" name="fnames" style="width:350px" readonly></center><br><br>';
              

              
         

              echo<<< button
              
              <span> <center><input type="submit" name="validateLogin" value="VALIDATE" class=" text-xl rounded-lg bg-black hover:bg-blue-800 text-white " style="width: 150px;height:50px"></center></span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<br>
              <span><center><u><a class="text-red-600" href="./">i put wrong roll number!!</a></u></center></span>
              button;
            }else{

              echo <<< form

              <div><label for="fname" class=" text-left text-xl">ROLL NUMBER</label><br>
                <input  class=" text-center text-xl" placeholder="ENTER YOUR ROLL NUMBER" type="text" id="rollno" name="rollno" style="width: 300px" ><br><br>
                        <span> <input type="submit" name="submit" value="GET DETAILS" class=" text-xl rounded-lg bg-black hover:bg-blue-800 text-white " style="width: 150px;height:50px"></span>

              form;

            }

            ?>
           

</form>
       
      </div>    
</div>
</body>
</html>