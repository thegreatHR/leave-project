<?php
include('server.php');
$sql="select * from function where id='1'";
$result=mysqli_query($conn,$sql);
$row=mysqli_fetch_assoc($result);
$maintain=$row['maintenance'];
if($maintain!=0){
    header("Location: maintenance.php");
}
?>