<?php
session_start();
include('server.php');
if(!isset($_SESSION['mailid']) && !isset($_SESSION['rollno']));{
    header("Location: index.php");
}
$rollno=$_SESSION['rollno'];

$sql = "select * from resister where ROLLNUMBER='$rollno';";
    $result=mysqli_query($conn,$sql);
    $row=mysqli_fetch_assoc($result);
    $sessionotp=$row['sessionotp'];
    $sessin=$_SESSION['sessionotp'];
if($sessionotp!=$sessin){
    unset($_SESSION['OTP']);
unset($_SESSION['mailid']);
session_destroy();

}
 
?>